# routers/robos.py
from typing import List, Optional
from fastapi import (
    APIRouter, Depends, HTTPException, status, Path, Response,
    UploadFile, File, Form
)
from sqlalchemy.orm import Session
import re
from unicodedata import normalize

from models.robos import Robo
from schemas.robos import RobosCreate, Robos as RoboSchema
from auth.dependencies import get_db, get_current_user
from models.users import User
from services.cache_service import cache_result, cache_service

router = APIRouter(prefix="/robos", tags=["Robos"])

# ---------------------------
# Helpers
# ---------------------------
def _to_schema(robo: Robo) -> RoboSchema:
    return RoboSchema(
        id=robo.id,
        nome=robo.nome,
        criado_em=robo.criado_em,
        performance=robo.performance,
        id_ativo=robo.id_ativo,
        tem_arquivo=bool(robo.arquivo_robo),
    )

def _clean_optional_int(raw: Optional[str]) -> Optional[int]:
    """Converte '', ' ', 'null', 'none' -> None; caso contrário tenta int()."""
    if raw is None:
        return None
    s = str(raw).strip().lower()
    if s in ("", "null", "none"):
        return None
    try:
        return int(s)
    except ValueError:
        raise HTTPException(status_code=400, detail="id_ativo deve ser inteiro ou ausente.")

# ---------- GET: Listar robôs (com cache) ----------
@router.get("/", response_model=List[RoboSchema], summary="Listar Robôs")
@cache_result(key_prefix="robos", ttl=600)
def listar_robos(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    itens = db.query(Robo).order_by(Robo.id).all()
    return [_to_schema(x) for x in itens]

# ---------- GET: Obter robô por ID ----------
@router.get("/{id}", response_model=RoboSchema, summary="Obter Robô")
def obter_robo(
    id: int = Path(..., gt=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    robo = db.query(Robo).filter(Robo.id == id).first()
    if not robo:
        raise HTTPException(status_code=404, detail="Robô não encontrado")
    return _to_schema(robo)

# ---------- POST: Criar novo robô (MULTIPART) ----------
@router.post(
    "/",
    response_model=RoboSchema,
    status_code=status.HTTP_201_CREATED,
    summary="Criar Robô (multipart/form-data, arquivo opcional)",
)
async def criar_robo_multipart(
    nome: str = Form(..., description="Nome do robô"),
    id_ativo: Optional[str] = Form(None, description="ID do ativo (opcional)"),
    performance: Optional[List[str]] = Form(
        None, description="Repita a chave: performance=a&performance=b"
    ),
    arquivo_robo: Optional[UploadFile] = File(
        None, description="Arquivo do robô (opcional, salvo como bytea)"
    ),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    id_ativo_int = _clean_optional_int(id_ativo)

    perf_list: Optional[List[str]] = None
    if performance is not None:
        perf_list = [p for p in performance if isinstance(p, str) and p.strip() != ""]
        if not perf_list:
            perf_list = None

    content: Optional[bytes] = None
    if arquivo_robo is not None:
        content = await arquivo_robo.read()
        if content == b"":
            content = None

    novo = Robo(
        nome=nome,
        performance=perf_list,
        id_ativo=id_ativo_int,
        arquivo_robo=content,
    )
    db.add(novo)
    db.commit()
    db.refresh(novo)

    cache_service.clear_pattern("robos:*")
    return _to_schema(novo)

# ---------- PUT: Atualizar robô (MULTIPART, igual ao POST) ----------
@router.put(
    "/{id}",
    response_model=RoboSchema,
    summary="Atualizar Robô (multipart/form-data, igual ao POST)",
)
async def atualizar_robo_multipart(
    id: int = Path(..., gt=0),
    nome: Optional[str] = Form(None, description="Novo nome (opcional)"),
    id_ativo: Optional[str] = Form(None, description="Novo id_ativo (opcional)"),
    performance: Optional[List[str]] = Form(
        None,
        description="Repita a chave: performance=a&performance=b (opcional)"
    ),
    arquivo_robo: Optional[UploadFile] = File(
        None, description="Novo arquivo do robô (opcional)"
    ),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    robo = db.query(Robo).filter(Robo.id == id).first()
    if not robo:
        raise HTTPException(status_code=404, detail="Robô não encontrado")

    # nome — só atualiza se veio (e não vazio)
    if nome is not None:
        nome = nome.strip()
        if nome:
            robo.nome = nome

    # id_ativo — só atualiza se veio a chave (permite limpar com vazio/null)
    if id_ativo is not None:
        robo.id_ativo = _clean_optional_int(id_ativo)

    # performance — só atualiza se a chave veio
    if performance is not None:
        lista = [p.strip() for p in performance if isinstance(p, str) and p.strip() != ""]
        robo.performance = lista if lista else None

    # arquivo — substitui somente se enviado
    if arquivo_robo is not None:
        content = await arquivo_robo.read()
        if content and content != b"":
            robo.arquivo_robo = content
        # Para remover ao enviar vazio, use: else: robo.arquivo_robo = None

    db.commit()
    db.refresh(robo)

    cache_service.clear_pattern("robos:*")
    return _to_schema(robo)

# ---------- GET: Download do arquivo ----------
@router.get("/download/{id}", summary="Download arquivo do Robô")
def download_arquivo_robo(
    id: int = Path(..., gt=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    robo = db.query(Robo).filter(Robo.id == id).first()
    if not robo:
        raise HTTPException(status_code=404, detail="Robô não encontrado")

    if not robo.arquivo_robo:
        raise HTTPException(status_code=404, detail="Robô não tem arquivo")

    # cria um nome de arquivo seguro a partir do nome do robô
    def _slugify(s: str) -> str:
        s = normalize("NFKD", s).encode("ascii", "ignore").decode("ascii")
        s = re.sub(r"[^\w\s.-]", "", s).strip().lower()
        s = re.sub(r"\s+", "_", s)
        return s or f"robo_{id}"

    filename = f"{_slugify(robo.nome)}.zip"
    headers = {"Content-Disposition": f'attachment; filename="{filename}"'}
    return Response(content=robo.arquivo_robo, media_type="application/zip", headers=headers)

# ---------- DELETE ----------
@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT, summary="Excluir Robô")
def deletar_robo(
    id: int = Path(..., gt=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    robo = db.query(Robo).filter(Robo.id == id).first()
    if not robo:
        raise HTTPException(status_code=404, detail="Robô não encontrado")

    db.delete(robo)
    db.commit()

    cache_service.clear_pattern("robos:*")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
